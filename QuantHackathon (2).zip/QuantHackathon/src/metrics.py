import numpy as np

def performance_stats(returns):

    cumulative = (1 + returns).prod() - 1

    annual_return = (1 + returns.mean())**52 - 1

    annual_vol = returns.std() * np.sqrt(52)

    sharpe = annual_return / annual_vol

    max_drawdown = ((1+returns).cumprod() / (1+returns).cumprod().cummax() - 1).min()

    hit_rate = (returns > 0).mean()

    avg_weekly = returns.mean()

    return {
        "Cumulative Return": cumulative,
        "Annual Return": annual_return,
        "Volatility": annual_vol,
        "Sharpe": sharpe,
        "Max Drawdown": max_drawdown,
        "Hit Rate": hit_rate,
        "Avg Weekly Return": avg_weekly
    }