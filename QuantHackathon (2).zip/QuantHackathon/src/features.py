import pandas as pd

def create_features(df):

    df = df.sort_values(["Ticker","Date"])

    df["Return_1d"] = df.groupby("Ticker")["Close"].pct_change()

    df["Return_5d"] = df.groupby("Ticker")["Close"].pct_change(5)

    df["MA10"] = df.groupby("Ticker")["Close"].transform(
        lambda x: x.rolling(10).mean()
    )

    df["MA20"] = df.groupby("Ticker")["Close"].transform(
        lambda x: x.rolling(20).mean()
    )

    df["Volatility"] = df.groupby("Ticker")["Return_1d"].transform(
        lambda x: x.rolling(10).std()
    )

    df["NextWeekReturn"] = df.groupby("Ticker")["Close"].shift(-5) / df["Close"] - 1

    df["Target"] = (df["NextWeekReturn"] > 0).astype(int)

    df = df.dropna()

    return df