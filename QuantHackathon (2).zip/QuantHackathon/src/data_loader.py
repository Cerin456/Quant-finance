import yfinance as yf
import pandas as pd

TICKERS = ["AAPL","MSFT","GOOGL","AMZN","META","TSLA","JPM","V","JNJ","BRK-B"]

def download_data(start="2017-01-01", end="2025-12-31"):

    data = yf.download(
        TICKERS,
        start=start,
        end=end,
        group_by="ticker",
        threads=False
    )

    frames = []

    for ticker in TICKERS:
        df = data[ticker].copy()
        df["Ticker"] = ticker
        df["Date"] = df.index
        frames.append(df)

    final = pd.concat(frames)
    final.reset_index(drop=True, inplace=True)

    return final