import pandas as pd
import numpy as np

def backtest_strategy(df):

    df["Week"] = df["Date"].dt.to_period("W")

    portfolio_returns = []

    weeks = df["Week"].unique()

    for w in weeks:

        week_data = df[df["Week"] == w]

        ranked = week_data.sort_values("PredProb", ascending=False)

        top2 = ranked.head(2)

        if len(top2) < 2:
            continue

        weekly_return = top2["NextWeekReturn"].mean()

        cost = 0.002

        net_return = weekly_return - cost

        portfolio_returns.append(net_return)

    returns = pd.Series(portfolio_returns)

    return returns